# Tram 自动驾驶场景测试报告

**生成时间**: 自动生成  
**测试场景数**: 5  

## 1. 实验配置

| 配置项 | 值 |
|--------|-----|
| 控制器 (标准/高速/短站台/道岔) | PI + LQR |
| 控制器 (U-turn) | MPC |
| 仿真频率 | 100 Hz |
| 控制频率 (PI+LQR) | 50 Hz |
| 控制频率 (MPC) | 20 Hz |
| 数据记录频率 | 20 Hz |

## 2. 综合指标汇总

| 场景 | 时长(s) | 距离(m) | 均速(m/s) | 横向误差 RMSE(m) | 横向误差 Max(m) | 航向误差 RMSE(°) | 航向误差 Max(°) | 速度跟踪 RMSE(m/s) |
|------|---------|---------|-----------|------------------|-----------------|------------------|-----------------|--------------------|
| 标准站点停靠 (60 km/h) | 93.2 | 419.9 | 4.50 | 0.000 | 0.000 | 0.00 | 0.00 | 3.505 |
| 高速站点停靠 (80 km/h) | 84.1 | 349.9 | 4.16 | 0.000 | 0.000 | 0.00 | 0.00 | 5.583 |
| 短站台停靠 (40 km/h) | 102.2 | 259.9 | 2.54 | 0.000 | 0.000 | 0.00 | 0.00 | 2.026 |
| 道岔换道 (8°) | 72.0 | 360.5 | 5.00 | 0.004 | 0.036 | 0.13 | 1.29 | 1.500 |
| 180° 弯道掉头 (R=15m) | 72.6 | 217.4 | 2.99 | 0.100 | 0.532 | 1.40 | 7.44 | 1.431 |

## 3. 各场景详细指标

### 标准站点停靠 (60 km/h)

| 指标 | 值 |
|------|-----|
| 运行时长 | 93.25 s |
| 行驶距离 | 419.93 m |
| 采样点数 | 1866 |
| 平均车速 | 4.50 m/s |
| 速度跟踪 RMSE | 3.505 m/s |
| 速度跟踪 MAE | 1.496 m/s |
| 速度跟踪 Max Error | 16.663 m/s |
| 横向误差 RMSE | 0.000 m |
| 横向误差 MAE | 0.000 m |
| 横向误差 Max | 0.000 m |
| 弯道段横向误差 Max | 0.000 m |
| 航向误差 RMSE | 0.00 ° |
| 航向误差 MAE | 0.00 ° |
| 航向误差 Max | 0.00 ° |
| 最大前轮转角 | 0.0 ° |
| 最大后轮转角 | 0.0 ° |
| 最大加速度指令 | 2.00 m/s² |
| 最大减速度指令 | -3.23 m/s² |

![speed](standard_stop/speed_tracking.png)
![lateral](standard_stop/lateral_error.png)
![heading](standard_stop/heading_error.png)
![steering](standard_stop/steering.png)
![trajectory](standard_stop/trajectory.png)
![accel](standard_stop/accel.png)

### 高速站点停靠 (80 km/h)

| 指标 | 值 |
|------|-----|
| 运行时长 | 84.10 s |
| 行驶距离 | 349.93 m |
| 采样点数 | 1683 |
| 平均车速 | 4.16 m/s |
| 速度跟踪 RMSE | 5.583 m/s |
| 速度跟踪 MAE | 2.411 m/s |
| 速度跟踪 Max Error | 22.222 m/s |
| 横向误差 RMSE | 0.000 m |
| 横向误差 MAE | 0.000 m |
| 横向误差 Max | 0.000 m |
| 弯道段横向误差 Max | 0.000 m |
| 航向误差 RMSE | 0.00 ° |
| 航向误差 MAE | 0.00 ° |
| 航向误差 Max | 0.00 ° |
| 最大前轮转角 | 0.0 ° |
| 最大后轮转角 | 0.0 ° |
| 最大加速度指令 | 2.00 m/s² |
| 最大减速度指令 | -4.50 m/s² |

![speed](highspeed_stop/speed_tracking.png)
![lateral](highspeed_stop/lateral_error.png)
![heading](highspeed_stop/heading_error.png)
![steering](highspeed_stop/steering.png)
![trajectory](highspeed_stop/trajectory.png)
![accel](highspeed_stop/accel.png)

### 短站台停靠 (40 km/h)

| 指标 | 值 |
|------|-----|
| 运行时长 | 102.25 s |
| 行驶距离 | 259.93 m |
| 采样点数 | 2046 |
| 平均车速 | 2.54 m/s |
| 速度跟踪 RMSE | 2.026 m/s |
| 速度跟踪 MAE | 0.725 m/s |
| 速度跟踪 Max Error | 11.111 m/s |
| 横向误差 RMSE | 0.000 m |
| 横向误差 MAE | 0.000 m |
| 横向误差 Max | 0.000 m |
| 弯道段横向误差 Max | 0.000 m |
| 航向误差 RMSE | 0.00 ° |
| 航向误差 MAE | 0.00 ° |
| 航向误差 Max | 0.00 ° |
| 最大前轮转角 | 0.0 ° |
| 最大后轮转角 | 0.0 ° |
| 最大加速度指令 | 2.00 m/s² |
| 最大减速度指令 | -2.67 m/s² |

![speed](short_platform/speed_tracking.png)
![lateral](short_platform/lateral_error.png)
![heading](short_platform/heading_error.png)
![steering](short_platform/steering.png)
![trajectory](short_platform/trajectory.png)
![accel](short_platform/accel.png)

### 道岔换道 (8°)

| 指标 | 值 |
|------|-----|
| 运行时长 | 72.00 s |
| 行驶距离 | 360.55 m |
| 采样点数 | 1441 |
| 平均车速 | 5.00 m/s |
| 速度跟踪 RMSE | 1.500 m/s |
| 速度跟踪 MAE | 0.561 m/s |
| 速度跟踪 Max Error | 8.333 m/s |
| 横向误差 RMSE | 0.004 m |
| 横向误差 MAE | 0.001 m |
| 横向误差 Max | 0.036 m |
| 弯道段横向误差 Max | 0.000 m |
| 航向误差 RMSE | 0.13 ° |
| 航向误差 MAE | 0.03 ° |
| 航向误差 Max | 1.29 ° |
| 最大前轮转角 | 9.4 ° |
| 最大后轮转角 | 1.7 ° |
| 最大加速度指令 | 2.00 m/s² |
| 最大减速度指令 | -1.48 m/s² |

![speed](switch_lane/speed_tracking.png)
![lateral](switch_lane/lateral_error.png)
![heading](switch_lane/heading_error.png)
![steering](switch_lane/steering.png)
![trajectory](switch_lane/trajectory.png)
![accel](switch_lane/accel.png)

### 180° 弯道掉头 (R=15m)

| 指标 | 值 |
|------|-----|
| 运行时长 | 72.65 s |
| 行驶距离 | 217.36 m |
| 采样点数 | 1454 |
| 平均车速 | 2.99 m/s |
| 速度跟踪 RMSE | 1.431 m/s |
| 速度跟踪 MAE | 0.593 m/s |
| 速度跟踪 Max Error | 8.000 m/s |
| 横向误差 RMSE | 0.100 m |
| 横向误差 MAE | 0.037 m |
| 横向误差 Max | 0.532 m |
| 弯道段横向误差 Max | 0.353 m |
| 航向误差 RMSE | 1.40 ° |
| 航向误差 MAE | 0.50 ° |
| 航向误差 Max | 7.44 ° |
| 最大前轮转角 | 20.0 ° |
| 最大后轮转角 | 20.0 ° |
| 最大加速度指令 | 1.92 m/s² |
| 最大减速度指令 | -1.73 m/s² |

![speed](uturn_180/speed_tracking.png)
![lateral](uturn_180/lateral_error.png)
![heading](uturn_180/heading_error.png)
![steering](uturn_180/steering.png)
![trajectory](uturn_180/trajectory.png)
![accel](uturn_180/accel.png)

## 4. 结论与建议

- **标准站点停靠**、**高速站点停靠**、**短站台停靠**：主要考核纵向速度跟踪与精准停车能力。
- **道岔换道**：考核横向跟踪与前后轮协同，关注横向误差峰值是否收敛。
- **180° 弯道掉头**：考核大曲率横向跟踪与姿态恢复，MPC 相比 LQR 在曲率阶跃处具有更好的预测能力。
- 若某场景横向误差 RMSE > 0.15 m 或出现持续发散，建议进一步调大 LQR/MPC 的 e_y 权重，或降低该场景参考速度。
